<?php

// $req est la variable cherchée
// $evidences est un tableau contenant les variables connues
function elim($req,$evidences){

	$bdd = new PDO('mysql:host=localhost;dbname=rpc','root','root',array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

	$reponse = $bdd->query('SELECT slug  FROM Variable');
	
	while($donnees = $reponse->fetch()){
		echo $donnees['slug'].'<br>';
		$variables[]=$donnees['slug'];
		//var_dump($variables);
	}

	echo "liste des var autres que req et evidences : <br>";
	foreach ($variables as $key => $value) {
		if (($value!=$req)&&(non_evidence($value,$evidences))) {
			echo $value."<br>";
		}
	}




}

function non_evidence($value,$evidences){
	$res=true;
	foreach ($evidences as $key => $val) {
		if($val==$value){
			$res=false;
		}
		# code...
	}
	return $res;
}

elim('AL',array("DR", "IN"));


?>